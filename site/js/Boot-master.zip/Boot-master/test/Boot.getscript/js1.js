log("Executing Script #1");
