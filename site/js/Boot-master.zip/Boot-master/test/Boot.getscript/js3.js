log("Executing Script #3");
