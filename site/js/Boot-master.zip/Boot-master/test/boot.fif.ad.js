document.write(":)");
document.write("<br>:P");
