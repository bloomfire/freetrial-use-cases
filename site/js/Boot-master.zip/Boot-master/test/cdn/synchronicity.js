// This file loads a couple other JS files.
Boot.getJS("javascript.php?num=2", function(){ Boot.log("Loaded synchronicity script #2"); });
Boot.getJS("javascript.php?num=3", function(){ Boot.log("Loaded synchronicity script #3"); });