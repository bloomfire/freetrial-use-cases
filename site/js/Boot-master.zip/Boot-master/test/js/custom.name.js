Boot.define({
	"custom": true
});
